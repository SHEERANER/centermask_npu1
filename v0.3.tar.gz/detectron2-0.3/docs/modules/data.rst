detectron2.data package
=======================

.. autodata:: detectron2.data.DatasetCatalog(dict)
    :annotation:

.. autodata:: detectron2.data.MetadataCatalog(dict)
    :annotation:

.. automodule:: detectron2.data
    :members:
    :undoc-members:
    :show-inheritance:

detectron2.data.detection\_utils module
---------------------------------------

.. automodule:: detectron2.data.detection_utils
    :members:
    :undoc-members:
    :show-inheritance:

detectron2.data.datasets module
---------------------------------------

.. automodule:: detectron2.data.datasets
    :members:
    :undoc-members:
    :show-inheritance:

detectron2.data.samplers module
---------------------------------------

.. automodule:: detectron2.data.samplers
    :members:
    :undoc-members:
    :show-inheritance:


detectron2.data.transforms module
---------------------------------------

.. automodule:: detectron2.data.transforms
    :members:
    :undoc-members:
    :show-inheritance:
    :imported-members:
